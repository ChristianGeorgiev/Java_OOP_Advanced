package ex6;

public interface Identifiable {
    String getId();
}
