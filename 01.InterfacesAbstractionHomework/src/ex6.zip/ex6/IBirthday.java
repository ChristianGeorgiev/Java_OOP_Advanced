package ex6;

public interface IBirthday {
    String getBirthday();
}
