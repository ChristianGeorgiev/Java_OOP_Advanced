package ex4;

public interface Calling {
    String call(String number);
}
