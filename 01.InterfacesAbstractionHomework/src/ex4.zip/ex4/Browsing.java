package ex4;

public interface Browsing {
    String browse(String url);
}
