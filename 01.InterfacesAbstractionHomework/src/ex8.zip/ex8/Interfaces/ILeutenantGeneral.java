package ex8.Interfaces;

import ex8.Soldiers.BasicSoldiers.Private;
import ex8.Soldiers.Soldier;

public interface ILeutenantGeneral {
    void addPrivate(Soldier prv);
}
