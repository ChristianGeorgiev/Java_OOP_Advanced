package ex8.Interfaces;

public interface IPrivate {
    double getSalary();
}
