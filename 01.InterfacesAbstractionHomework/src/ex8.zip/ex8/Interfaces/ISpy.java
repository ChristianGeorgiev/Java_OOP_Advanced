package ex8.Interfaces;

public interface ISpy {
    int getCodeNumber();
}
