package ex8.Interfaces;

import ex8.Soldiers.SpecialisedSoldiers.Activities.Mission;

public interface ICommando {
    void addMission(Mission mission);
}
