package ex8.Interfaces;

import ex8.Soldiers.SpecialisedSoldiers.Activities.Repair;

public interface IEngineer {
    void addRepair(Repair repair);
}
