package ex5;

public interface Identifiable {
    String getId();
}
