package ex8.Interfaces;

public interface ISpy {
    String getCodeNumber();
}
