package ex8.Interfaces;

public interface ISpecialisedSoldier {
    String getCorps();
}
