package ex3;

public interface Drivable {
    String useBrakes();
    String pushGas();

}
