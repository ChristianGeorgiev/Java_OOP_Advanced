package ex2;

public interface Birthable {
    String getBirthdate();
}
