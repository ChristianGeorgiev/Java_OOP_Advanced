package ex2;

public interface Identifiable {
    String getId();
}
