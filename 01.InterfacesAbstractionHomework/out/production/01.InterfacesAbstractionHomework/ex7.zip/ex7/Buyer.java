package ex7;

public interface Buyer {
    void buyFood();
}
