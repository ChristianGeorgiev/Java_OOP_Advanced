package ex7;

public interface IBirthday {
    String getBirthday();
}
