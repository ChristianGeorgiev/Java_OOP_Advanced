package ex7;

public interface Identifiable {
    String getId();
}
