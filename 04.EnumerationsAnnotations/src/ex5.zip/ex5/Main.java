package ex5;

public class Main {
}
