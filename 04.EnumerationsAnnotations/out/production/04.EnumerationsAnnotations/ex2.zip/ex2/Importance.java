package ex2;

public enum Importance {
    LOW, NORMAL, MEDIUM, HIGH;
}
