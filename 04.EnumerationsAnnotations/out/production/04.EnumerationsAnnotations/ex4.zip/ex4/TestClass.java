package ex4;

@Subject(categories = {"Test", "Annotations"})
public class TestClass {

}
