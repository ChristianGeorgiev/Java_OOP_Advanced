package ex3.Enums;

public enum CoffeeType {
    ESPRESSO, LATTE, IRISH;
}
