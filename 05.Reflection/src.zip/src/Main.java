import java.sql.Ref;
import java.util.Arrays;

public class Main {
    public static void main(String[] args) throws IllegalAccessException, InstantiationException {
        Class reflectionClass = Reflection.class;

        Reflection ref = (Reflection) reflectionClass.newInstance();

        System.out.println(reflectionClass);
        System.out.println(reflectionClass.getSuperclass());
        Class[] interfaces = reflectionClass.getInterfaces();
        for (Class anInterface : interfaces) {
            System.out.println(anInterface);
        }

        System.out.println(ref.toString());
    }
}
