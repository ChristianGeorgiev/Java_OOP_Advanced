package ex4;

public interface Person {
    String getName();
    String sayHello();
}
