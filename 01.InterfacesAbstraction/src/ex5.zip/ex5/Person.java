package ex5;

public interface Person {
    String getName();
    String sayHello();
}
