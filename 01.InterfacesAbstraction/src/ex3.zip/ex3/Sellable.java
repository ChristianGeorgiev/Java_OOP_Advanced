package ex3;

public interface Sellable extends Car {
    double getPrice();
}
