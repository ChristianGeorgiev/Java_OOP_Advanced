package ex3;

public interface Rentable extends Car {
    int getMinRentDay();
    double getPricePerDay();
}
