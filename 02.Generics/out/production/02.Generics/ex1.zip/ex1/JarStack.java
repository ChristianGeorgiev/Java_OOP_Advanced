package ex1;

public interface JarStack<E> {
    void add(E element);
    E remove();
}
