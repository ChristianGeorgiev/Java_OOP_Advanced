package observer;

public interface Observer {
    void update (int reward);
}
