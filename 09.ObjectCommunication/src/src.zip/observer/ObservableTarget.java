package observer;

import models.Target;

public interface ObservableTarget extends Target, Subject {

}
