package commands;

public interface Command {
    void execute();
}
