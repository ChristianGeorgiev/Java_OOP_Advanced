package commandExecutors;

import commands.Command;

public interface Executor {
    void executeCommand(Command command);
}
